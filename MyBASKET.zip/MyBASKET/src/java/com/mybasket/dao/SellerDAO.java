package com.mybasket.dao;

import com.mybasket.bean.Seller;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SellerDAO {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mybasket", "root", "root");

        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static int insert(Seller s) {
        int status = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "insert into seller(fname,lname,email,password,mobile,address,state) values(?,?,?,?,?,?,?)");
            ps.setString(1, s.getFname());
            ps.setString(2, s.getLname());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getPassword());
            ps.setInt(5, s.getMobile());
            ps.setString(6, s.getAddress());
            ps.setString(7, s.getState());
            
            status = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static Seller getByEmail(String email) {
        Seller s = null;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from seller where email='"+email+"'");
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                s = new Seller();
                s.setFname(rs.getString("fname"));
                s.setLname(rs.getString("lname"));
                s.setEmail(rs.getString("email"));
                s.setPassword(rs.getString("password"));
                s.setMobile(rs.getInt("mobile"));
                s.setAddress(rs.getString("address"));
                s.setState(rs.getString("state"));
                s.setId(rs.getInt("sid"));

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }
    
    public static List<Seller> getAllSeller(){
        List<Seller> list=new ArrayList<Seller>();
        try{
            Connection con=getConnection();
            PreparedStatement ps=con.prepareStatement("select * from seller");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Seller s=new Seller();
                s.setFname(rs.getString("fname"));
                s.setLname(rs.getString("lname"));
                s.setEmail(rs.getString("email"));
                s.setPassword(rs.getString("password"));
                s.setMobile(rs.getInt("mobile"));
                s.setAddress(rs.getString("address"));
                s.setState(rs.getString("state"));
                s.setId(rs.getInt("sid"));
                
            }
        }catch(Exception e){
            System.out.println("Error in DAO "+e);
        }
        return list;
    }
}

package com.mybasket.dao;

import com.mybasket.bean.Cart;
import static com.mybasket.dao.UserDAO.getConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {

    public static int insert(Cart c) {
        Connection con;
        PreparedStatement psInsertDatabase = null;
        int rowsEffected = 0;
        try {
            con = getConnection();
            psInsertDatabase = con.prepareStatement("insert into cart(item_details,price,quantity) values(?,?,?);");
            psInsertDatabase.setString(1, c.getItem_details());
            psInsertDatabase.setInt(2, c.getPrice());
            psInsertDatabase.setInt(3, c.getQuantity());
            rowsEffected = psInsertDatabase.executeUpdate();

        } catch (Exception e) {
            System.out.println(e);
        }
        return rowsEffected;
    }

    public static List<Cart> display() {
        List<Cart> list = new ArrayList<>();

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from Cart;");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cart cart = new Cart();
                cart.setItem_details(rs.getString("item_details"));
                cart.setPrice(rs.getInt("price"));
                cart.setQuantity(rs.getInt("quantity"));
                list.add(cart);
            }
                rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;

    }
    
    public static int cartitems() {
        Connection con;
        PreparedStatement psInsertDatabase = null;
        int rowsEffected = 0;
        try {
            con = getConnection();
            psInsertDatabase = con.prepareStatement("select count(*) as itemcount from cart;");
           ResultSet rs = psInsertDatabase.executeQuery();
           rs.next();
           rowsEffected=rs.getInt("itemcount");
           rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return rowsEffected;
    }
}

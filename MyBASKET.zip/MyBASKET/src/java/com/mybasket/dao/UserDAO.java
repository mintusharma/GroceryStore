
package com.mybasket.dao;

import com.mybasket.bean.User;
import java.sql.*;

public class UserDAO {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mybasket", "root", "root");

        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static int insert(User u) {
        int status = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                   "insert into registration(fname,lname,email,password,mobile) values(?,?,?,?,?)");
            ps.setString(1, u.getFname());
            ps.setString(2, u.getLname());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getPassword());
            ps.setInt(5, u.getMobile());

            status = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static User getRecordByEmail(String email){
        User u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from registration where email='"+email+"'");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new User();    
            u.setFname(rs.getString("fname")); 
            u.setLname(rs.getString("lname")); 
            u.setEmail(rs.getString("email")); 
            u.setPassword(rs.getString("password")); 
            u.setMobile(rs.getInt("mobile"));
            u.setId(rs.getInt("userid"));
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
    }
    
     public static User update(String email){
        User u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("update registration set fname=?,lname=?,email=?,password=?,"
                + "mobile=? where email='"+email+"'");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new User();    
            u.setFname(rs.getString("fname")); 
            u.setLname(rs.getString("lname")); 
            u.setEmail(rs.getString("email")); 
            u.setPassword(rs.getString("password")); 
            u.setMobile(rs.getInt("mobile"));
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
    }
    

}

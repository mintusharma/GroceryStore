package com.mybasket.bean;

import java.sql.Date;

public class AddProduct {

    private static int pid, price;
    private String pname, pimage, categories;
    private Date mfgdate, expdate;

    public static int getPid() {
        return pid;
    }

    public static void setPid(int pid) {
        AddProduct.pid = pid;
    }

    public static int getPrice() {
        return price;
    }

    public static void setPrice(int price) {
        AddProduct.price = price;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public Date getMfgdate() {
        return mfgdate;
    }

    public void setMfgdate(Date mfgdate) {
        this.mfgdate = mfgdate;
    }

    public Date getExpdate() {
        return expdate;
    }

    public void setExpdate(Date expdate) {
        this.expdate = expdate;
    }

}

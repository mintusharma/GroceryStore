  
package com.mybasket.bean;

 
public class Cart {
    private int cart_id ; 
 private String item_details;
 private int  price;  
 private int quantity;  

    /**
     * @return the cart_id
     */
    public int getCart_id() {
        return cart_id;
    }

    /**
     * @param cart_id the cart_id to set
     */
    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }

    /**
     * @return the item_details
     */
    public String getItem_details() {
        return item_details;
    }

    /**
     * @param item_details the item_details to set
     */
    public void setItem_details(String item_details) {
        this.item_details = item_details;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

     
}
